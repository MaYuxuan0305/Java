package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class GroceryListAdapter extends RecyclerView.Adapter<GroceryViewHolder>{
   private ArrayList<Grocery>groceries;


    public GroceryListAdapter(ArrayList<Grocery>groceries){
        this.groceries= groceries;
    }
    @Override
    @NonNull
    public GroceryViewHolder onCreateViewHolder(@NonNull ViewGroup  parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_grocery,parent, false);
        return new GroceryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroceryViewHolder holder, int position) {
        Grocery grocery = groceries.get(position);
        holder.textGroceryName.setText(grocery.getName());
        holder.textGroceryNote.setText(grocery.getNote());

        final int pos = position;

        holder.imageDelete .setOnClickListener(view -> {
            Grocery groceryToRemove = groceries.get(pos);
            String groceryNameToRemove = groceryToRemove.getName();
            ListGrocery.getInstance().removeGrocery(groceryNameToRemove);
            notifyItemRangeRemoved(pos);
        });
        
        holder.imageEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (holder.editTextGroceryNote.getVisibility() == View.VISIBLE) {
                    String name = holder.textGroceryName.getText().toString(); // 获取食品名称
                    Grocery grocery = ListGrocery.getInstance().getGroceryByName(name); // 根据名称获取食品对象
                    if (grocery != null) {
                        grocery.setNote(holder.editTextGroceryNote.getText().toString());
                        holder.editTextGroceryNote.setVisibility(View.GONE);
                        notifyDataSetChanged();
                    }
                } else {
                    holder.editTextGroceryNote.setVisibility(View.VISIBLE);
                }
            }
        });
        
    }

    private void notifyItemRangeRemoved(int pos) {
    }

    @Override
    public int getItemCount() {
        return groceries.size();
    }
}

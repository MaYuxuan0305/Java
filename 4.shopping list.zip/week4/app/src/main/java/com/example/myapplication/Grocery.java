package com.example.myapplication;


public class Grocery {
    private String name;
    private String note;
    private long timeAdded;

    public Grocery(String name,String note){
        this.name = name;
        this.note = note;
        this.timeAdded = System.currentTimeMillis();//设置当前时间为默认时间
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;   //可以动态的修改购物项的名称而不需要创建新的购物项实例
    }
    public String getNote(){
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public long getTimeAdded() {
        return timeAdded;
    }
}

package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button buttonAddNewGrocery;

    private RecyclerView rvGroceries;
    private GroceryListAdapter adapter;
    private ImageView imageAlphabet;
    private ImageView imageTime;
    private ListGrocery listGrocery;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAddNewGrocery = findViewById(R.id.buttonAddNewGrocery);
        rvGroceries = findViewById(R.id.rvGroceries);
        imageAlphabet = findViewById(R.id.imageAlphabet);
        imageTime = findViewById(R.id.imageTime);

        listGrocery = ListGrocery.getInstance();
        adapter = new GroceryListAdapter((ArrayList<Grocery>) listGrocery.getGroceries());
        rvGroceries.setLayoutManager(new LinearLayoutManager(this));
        rvGroceries.setAdapter(adapter);


        buttonAddNewGrocery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddGroceryActivity.class);
                startActivity(intent);
            }
        });

        //设置布局管理器
        /*LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rvGroceries.setLayoutManager(layoutManager);

        ListGrocery listGrocery = ListGrocery.getInstance();
        adapter = new GroceryListAdapter(this, listGrocery.getGroceries());

        //设置适配器
        rvGroceries.setAdapter(adapter);*/

        imageAlphabet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listGrocery.sortGroceriesByAlphabet();
                adapter.notifyDataSetChanged();
            }
        });

        imageTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listGrocery.sortGroceriesByTime();
                adapter.notifyDataSetChanged();
            }
        });


        /*imageAlphabet.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onClick(View v) {
                listGrocery.sortGroceriesByAlphabet();
                adapter.notifyDataSetChanged();

            }
        });

        imageTime.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onClick(View v) {
                listGrocery.sortGroceriesByTime();
                adapter.notifyDataSetChanged();

            }
        });*/
    }

}
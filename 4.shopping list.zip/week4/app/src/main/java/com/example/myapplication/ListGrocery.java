package com.example.myapplication;

import java.util.ArrayList;
import java.util.Collections;//操作集合的静态方法，对集合进行排序、查找最大值最小值等
import java.util.Comparator;//用于定义对象之间的比较
import java.util.List;

public class ListGrocery {
    private static ListGrocery instance;
    private List<Grocery> groceries;

    private ListGrocery() {

        groceries = new ArrayList<>();
    }

    public static ListGrocery getInstance() {
        if (instance == null) {
            instance = new ListGrocery();
        }
        return instance;
    }

    public void addGrocery(Grocery grocery) {

        groceries.add(grocery);
    }

    public void removeGrocery(String name){
        Grocery rem = getGroceryByName(name);
        if (rem !=null){
            groceries.remove(rem);
        }
    }

    public List<Grocery> getGroceries(){
        return groceries;
    }

    public Grocery getGroceryByName(String name){
        for (Grocery grocery:groceries){
            if(grocery.getName().equals(name)){
                return grocery;
            }
        }

        return null;
    }

    public void sortGroceriesByAlphabet() {
        Collections.sort(groceries, Comparator.comparing(Grocery::getName));
    }

    public void sortGroceriesByTime() {
        Collections.sort(groceries, Comparator.comparing(Grocery::getTimeAdded));
    }

   /* public void sortGroceriesByAlphabet(){
        Collections.sort(groceries, new Comparator<Grocery>() {
            @Override
            public int compare(Grocery g1, Grocery g2) {
                return g1.getName().compareToIgnoreCase(g2.getName());
                }

        });
    }

    public void sortGroceriesByTime(){
        Collections.sort(groceries, new Comparator<Grocery>() {
            @Override
            public int compare(Grocery o1, Grocery o2) {
                return o1.getTimeAdded().compareTo(o2.getTimeAdded());
            }
        });
    }*/



}



